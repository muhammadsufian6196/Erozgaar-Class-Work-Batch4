<?php 
		$connection = new mysqli("localhost","root","",'crud')OR DIE("ERROR IN DATABASE CONNECTIVITY");
		//echo phpversion();
		// $connection = mysqli_connect();	
	 ?>

<?php  
	if (  isset(  $_REQUEST['submit_product']  )  ) {
		# code...
		$nameOfProduct = $_REQUEST['product_name'];
		$productBrand = $_REQUEST['product_brand'];
		$productPrice = $_REQUEST['product_price'];
		$productDescription = $_REQUEST['product_description'];

		//echo $nameOfProduct." ".$productBrand;
		//echo " ".$productPrice." ".$productDescription;
		$insertQuery = $connection->query("INSERT INTO `products`(`product_name`,
			`product_price`,
			`product_brand`,
			`product_description`,
			`created_at`) VALUES (
			'$nameOfProduct',$productPrice,'$productBrand','$productDescription','date()')");
		if ($insertQuery) {
			# code...
			echo "<script>alert('Data Inserted');
				window.location = '../index.php';
			</script>";
		}
		else{
			echo "Error :" .mysqli_error($connection);
		}
	}

?>