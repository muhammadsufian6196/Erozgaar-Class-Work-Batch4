<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Products CRUD</title>
</head>
<body>
	<?php 
		$connection = new mysqli("localhost","root","",'crud')OR DIE("ERROR IN DATABASE CONNECTIVITY");
		//echo phpversion();	
	 ?>
	 <table border="1px solid black">
	 	<thead>
	 		<tr>
	 			<th>Id</th>
	 			<th>Name</th>
	 			<th>Price</th>
	 			<th>Brand</th>
	 			<th>Description</th>
	 			<th>Created At</th>
	 			<th>Updated At</th>
	 			<th>Status</th>
	 			<th>EDIT / DELETE</th>
	 		</tr>
	 	</thead>
	 	<tbody>
	 		<?php 
	 			$selectQuery = $connection->query("SELECT * FROM `products`");
	 			while($data = mysqli_fetch_assoc($selectQuery)):
	 		?>	
				<tr>
					<td><?=$data['product_id'];?></td>
					<td><?=$data['product_name'];?></td>
					<td><?=$data['product_price'];?></td>
					<td><?=$data['product_brand'];?></td>
					<td><?=$data['product_description'];?></td>
					<td><?=$data['created_at'];?></td>
					<td><?=$data['updated_at'];?></td>
					<td><?=$data['status'];?></td>
					<td><a href="index.php?edit_id=<?=$data['product_id'];?>">EDIT</a> |<a onclick="return confirm('Are You Sure You Want to Delete the Record?');" href="index.php?delete_id=<?=$data['product_id'];?>">Delete</a></td>
				</tr>

			<?php
	 			endwhile;
	 		 ?>
	 	</tbody>
	 </table>
	<form action="scripts/insert.php" method="POST">
		<input type="text" placeholder="Enter Product Name" maxlength="255" name="product_name">
		<br>
		<input type="number" placeholder="Enter Product Price" maxlength="11" name="product_price">
		<br>
		<input type="text" placeholder="Enter Product Brand" maxlength="255" name="product_brand">
		<br>
		<textarea name="product_description"  cols="30" rows="10">Enter Product Description</textarea>
		<br>
		<input type="submit" name="submit_product" value="INSERT DATA !"> 
	</form>
	<?php 

	if (isset($_REQUEST['edit_id'])) {
 	# code...
 	$id = $_REQUEST['edit_id'];
 	$updateQuery =$connection->query("SELECT * FROM `products` WHERE `product_id`=$id");
 	while($formData = mysqli_fetch_assoc($updateQuery)):
 		?>
	<form action="scripts/insert.php" method="POST">
		<input type="text" value="<?=$formData['product_name'];?>" maxlength="255" name="product_name">
		<br>
		<input type="number" value="<?=$formData['product_price'];?>" maxlength="11" name="product_price">
		<br>
		<input type="text" value="<?=$formData['product_brand'];?>" maxlength="255" name="product_brand">
		<br>
		<textarea name="product_description"  cols="30" rows="10"><?=$formData['product_name'];?></textarea>
		<br>
		<input type="submit" name="update_product" value="INSERT DATA !"> 
	</form>
		<?php
 	endwhile;
 } ?>

</body>
</html>


<?php 

if (isset($_REQUEST['delete_id'])) {
 	# code...
 	$id = $_REQUEST['delete_id'];
 	$connection->query("DELETE FROM `products` WHERE `product_id`=$id");
 	echo "<script>window.location='index.php';</script>";
 } ?>